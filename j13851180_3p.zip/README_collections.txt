Sun Collections API
repackaged for installation by Oracle Applications

Source of this README file: collections.zip

Content description: Java API for dealing with collections of objects.
This API is part of the standard Java 2 distribution, but is not available
in the standard Java 1.1 distribution.

Java namespace(s) included:
  com/sun/java/util/collections

This archive file contains Java classes and resource files that have been
repackaged for easy delivery and patching to Oracle Applications customers.
If you are viewing this README from an archive or directory other than the
source listed above, please note that this README applies only to files that
are within the above listed namespace(s).
