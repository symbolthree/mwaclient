Oracle8i Aurora Client, version 8.1.6
repackaged for installation by Oracle Applications

Source of this README file: aurora_client.jar

Content Description:
  Oracle8i Aurora CORBA client
  with backport for bug 1199486

  NOTE: This rehosted version of aurora_client.zip differs from the version
  in ORACLE_HOME, as it removes a set of classes that conflict with vbj.zip
  and the JDBC 8.1.7 drivers. See bugs 1324998 and 1634530 for more detail.

Java namespace(s) included:
  oracle/aurora/
  com/sun/jndi/
  com/sun/naming/
  javax/naming/
  javax/jts/
  javax/ejb/
  org/omg/
  md5/*

This archive file contains Java classes and resource files that have been
repackaged for easy delivery and patching to Oracle Applications customers.
If you are viewing this README from an archive or directory other than the
source listed above, please note that this README applies only to files that
are within the above listed namespace(s).
